<a href="/">
    <img src="{{ asset('Image/Logo/logo-smk.png') }}" class="size-40 w-full" alt="">
</a>
