{{-- <div class="my-8">
    <div class="relative z-0 w-full mb-5 group">
        <textarea type="text" name="materitext" id="myeditorinstance"
            class="block py-2.5 px-0 w-full h-40 text-sm text-black bg-transparent border-0 border-b-2 border-gray-300 appearance-none focus:outline-none focus:ring-0 focus:border-blue-600 peer"
            placeholder=""> </textarea>
    </div>
</div> --}}

<form method="post">
    <textarea name="myeditorinstance" id="myeditorinstance"></textarea>
</form>
