<script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"></script>

<main-layout>
    <title>E-Learning</title>
    <x-sidebar>
        <div class="">
            @if (Auth::user()->roles == 'siswa')
                <div class="relative">
                    <h1 class="text-2xl">
                        Selamat Datang, <span class="capitalize font-bold">{{ Auth::user()->name }}</span>✋🏻
                    </h1>
                </div>
            @elseif(Auth::user()->roles == 'guru')
                @if ($guru->gender == 'Laki-Laki')
                    <div class="relative">
                        <h1 class="text-2xl">
                            Selamat Datang, Bapak <span class="capitalize font-bold">{{ Auth::user()->name }}</span>
                        </h1>
                    </div>
                @elseif($guru->gender == 'Perempuan')
                    <div class="relative">
                        <h1 class="text-2xl">
                            Selamat Datang, Ibu <span class="capitalize font-bold">{{ Auth::user()->name }}</span>
                        </h1>
                    </div>
                @endif
            @endif
            <div class="relative">
                @if (Auth::user()->roles == 'siswa' || Auth::user()->roles == 'guru')
                    @foreach ($mapel as $data)
                        <div
                            class="w-full h-fit mx-auto mt-1 drop-shadow border-2 border-[#000] rounded-lg p-2 transition ease-in-out delay-150 hover:-translate-y-1 hover:scale-90 duration-300">
                            <a href="{{ route('open-mapel', $data->slug) }}">
                                <div class="grid grid-cols-1 md:flex">
                                    <div class="flex flex-col md:px-3">
                                        <div class="max-h-10 md:px-2">
                                            <h2 class="text-center md:text-left text-lg md:text-4xl font-bold py-1">
                                                {{ $data->name_mapel }} ({{ $data->kode_mapel }}) :
                                                {{ $data->nameGuru }}
                                            </h2>
                                        </div>
                                    </div>
                                </div>
                            </a>
                        </div>
                    @endforeach
                @else
                    <p>
                        <span class="capitalize bold text-2xl">{{ Auth::user()->name }},</span>
                        <br>
                        Anda tidak memiliki akses di halaman ini!
                    </p>
                @endif
            </div>
        </div>
    </x-sidebar>
</main-layout>
